def hello_world(request):
    return f"Hello, World!"
